# T.DAY — Plataforma de Playlists

> 10 dias · 10 playlists · Esportes & Academia · 25–50 anos

Plataforma web completa do projeto T.DAY — campanha de lançamento de playlists no Spotify com estratégia viral, dashboard de analytics e guia de monetização.

---

## 🚀 Demo ao vivo

👉 **[Ver plataforma](https://SEU-USUARIO.github.io/tday)**

---

## 📁 Estrutura do projeto

```
tday/
├── index.html              # Plataforma completa (3 seções)
├── assets/
│   └── covers/             # Capas SVG das 10 playlists
│       ├── d1-beast-mode-ignition.svg
│       ├── d2-cardio-fire-run.svg
│       ├── d3-game-day-hype.svg
│       ├── d4-active-recovery-flow.svg
│       ├── d5-domination-mid-week.svg
│       ├── d6-weekend-warrior.svg
│       ├── d7-sunday-grind-mentality.svg
│       ├── d8-champions-blueprint.svg
│       ├── d9-final-push.svg
│       └── d10-tday-ultimate.svg
├── docs/
│   └── monetizacao.md      # Guia de monetização detalhado
└── README.md
```

---

## 🎵 As 10 Playlists

| Dia | Nome | Vibe |
|-----|------|------|
| D1 | Beast Mode Ignition | Força máxima |
| D2 | Cardio Fire Run | Corrida & HIIT |
| D3 | Game Day Hype | Esportes coletivos |
| D4 | Active Recovery Flow | Alongamento |
| D5 | Domination Mid-Week | Musculação pesada |
| D6 | Weekend Warrior | Outdoor & Crossfit |
| D7 | Sunday Grind Mentality | Foco & Disciplina |
| D8 | Champion's Blueprint | Elite performance |
| D9 | Final Push — No Days Off | Antecipação |
| D10 | T.DAY Ultimate Collection | Grand Finale |

---

## 📊 Funcionalidades da plataforma

- **Playlists interativas** — hover na capa revela músicas e artistas
- **Dashboard de analytics** — plays, saves, ouvintes únicos, top faixas
- **Guia de monetização** — 6 fontes de receita + plano de ação 30 dias

---

## 💰 Monetização

Veja o guia completo em [`docs/monetizacao.md`](docs/monetizacao.md)

Resumo das fontes:
1. Playlist Placement (R$ 500–5K/mês)
2. Parcerias com marcas esportivas
3. Links de afiliado
4. Consultoria de playlist
5. Curso / Infoproduto
6. Comunidade premium

---

## 🌐 Deploy no GitHub Pages

1. Faça o fork ou upload deste repositório
2. Vá em **Settings → Pages**
3. Em "Source" selecione **main branch / root**
4. Aguarde ~1 minuto
5. Acesse: `https://SEU-USUARIO.github.io/tday`

---

## 📱 Conectar dados reais do Spotify

Para substituir os dados simulados do dashboard por dados reais:

1. Acesse [artists.spotify.com](https://artists.spotify.com) (gratuito)
2. Reivindique seu perfil de curador
3. Acesse a API em [developer.spotify.com](https://developer.spotify.com)
4. Substitua os dados hardcoded em `index.html` pelos retornos da API

---

**T.DAY** — Feito para quem não descansa.
