# T.DAY — Guia de Monetização

> Como transformar playlists em receita real, rápido e com custo zero ou mínimo.

---

## 6 Fontes de Receita

### 1. 🥇 Playlist Placement — R$ 500–5K/mês
**O que é:** Artistas e gravadoras pagam para ter músicas incluídas em playlists com audiência qualificada.

**Como fazer:**
- Com 1K+ seguidores já dá para começar
- Crie uma página simples no [Beacons.ai](https://beacons.ai) (gratuito)
- Divulgue em grupos de artistas independentes no Facebook, WhatsApp e Instagram
- Preço inicial: R$ 150–300 por faixa por 30 dias

**Onde encontrar clientes:**
- Grupos "Artistas Independentes Brasil" no Facebook
- Fóruns de produtores no Discord
- DMs diretos para artistas no Instagram com menos de 50K seguidores

---

### 2. 🤝 Parcerias com marcas — R$ 1K–20K/deal
**O que é:** Marcas pagam para aparecer na descrição da playlist, bio e conteúdo nas redes.

**Como fazer:**
- Monte um media kit de 1 página (Canva gratuito) com: seguidores, plays, perfil do público
- E-mail direto para o setor de marketing das marcas
- Foque em marcas de nicho antes das grandes (resposta mais rápida)

**Marcas-alvo para o T.DAY:**
- Suplementos: Integral Médica, Max Titanium, Probiótica
- Apps: Strava, Nike Run Club, Freeletics
- Academias: SmartFit, Bodytech, academias locais
- Roupas: Olympikus, Fila, Under Armour BR

---

### 3. 🔗 Afiliados — R$ 300–3K/mês passivo
**O que é:** Comissão por cada venda gerada pelo seu link.

**Plataformas gratuitas:**
- [Hotmart](https://hotmart.com) — produtos digitais (cursos de treino, nutrição)
- [Amazon Afiliados](https://afiliados.amazon.com.br) — equipamentos, suplementos
- [Monetizze](https://monetizze.com.br) — físicos e digitais

**Como usar:**
- Link na bio do Spotify e Instagram
- Mencionar na descrição das playlists ("Treine com os suplementos que usamos")

---

### 4. 🎧 Consultoria de Playlist — R$ 200–800/hora
**O que é:** Vender o método T.DAY como serviço para empresas e influenciadores.

**Clientes ideais:**
- Academias que querem trilha sonora personalizada
- Eventos esportivos (maratonas, crossfit, campeonatos)
- Influenciadores fitness que querem lançar playlists próprias
- Marcas que precisam de playlist para vídeos e conteúdo

---

### 5. 📚 Curso / Infoproduto — R$ 97–497/aluno
**O que é:** Vender o método T.DAY como curso digital.

**Título sugerido:** "Playlists que Vendem: o Método T.DAY para Criar, Viralizar e Monetizar no Spotify"

**Plataformas gratuitas para hospedar:**
- [Hotmart](https://hotmart.com)
- [Kiwify](https://kiwify.com.br)
- [Eduzz](https://eduzz.com)

**Conteúdo do curso (10 módulos):**
1. Estratégia de 10 dias
2. Curadoria de playlist viral
3. Design de capas profissionais
4. Spotify for Artists na prática
5. Criação de conteúdo para cada dia
6. Collabs e parcerias
7. Analytics e decisões de dados
8. Playlist Placement: como cobrar
9. Parcerias com marcas: media kit e abordagem
10. Escalar para R$ 10K/mês

---

### 6. 👥 Comunidade Premium — R$ 47–97/membro/mês
**O que é:** Acesso recorrente a conteúdo exclusivo, curadoria antecipada e desafios.

**O que oferecer:**
- Acesso antecipado (3 dias antes) a cada playlist
- Desafios mensais de treino com playlist temática
- Curadoria de músicas com os membros
- Lives mensais de bastidores
- Grupo fechado com network de atletas e criadores

**Meta conservadora:**
- 50 membros × R$ 97 = R$ 4.850/mês recorrente
- 100 membros × R$ 97 = R$ 9.700/mês recorrente

**Plataformas:**
- WhatsApp (gratuito, até 100 membros)
- Discord (gratuito, ilimitado)
- Hotmart Club (pago, mas integra pagamento automático)

---

## 📅 Plano de 30 dias

| Semana | Foco | Meta de receita |
|--------|------|-----------------|
| 1 | Spotify for Artists + media kit + primeiros placements | R$ 300–600 |
| 2 | 10 abordagens de marca por dia + afiliados no ar | R$ 500–1.200 |
| 3 | Fechar 1 parceria de marca + 5 placements | R$ 1.000–2.500 |
| 4 | Lançar comunidade premium (meta: 20 membros) | R$ 2.000–4.000 |

**Total mês 1: R$ 800–2.000** (conservador)

---

## 🔧 Ferramentas gratuitas necessárias

| Ferramenta | Para que serve |
|-----------|----------------|
| [Spotify for Artists](https://artists.spotify.com) | Analytics reais |
| [Canva](https://canva.com) | Media kit e capas |
| [Beacons.ai](https://beacons.ai) | Página de placement |
| [Hotmart](https://hotmart.com) | Curso e comunidade |
| [Notion](https://notion.so) | Organizar propostas |
| [Calendly](https://calendly.com) | Agendar reuniões |

---

**T.DAY** — A playlist é o produto. A audiência é o ativo. A consistência é o negócio.
